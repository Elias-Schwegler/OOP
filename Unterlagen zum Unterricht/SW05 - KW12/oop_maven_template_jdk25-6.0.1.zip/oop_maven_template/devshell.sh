#!/bin/bash
#
# Copyright 2026 Hochschule Luzern Informatik.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

VERSION="$1"
if [ -z "$VERSION" ]; then
	VERSION="3.9.13"
fi
IMAGE="rgisler/maven:${VERSION}-temurin-25"
docker pull "$IMAGE"
docker run -it --rm --workdir "/work" -v "$(pwd):/work" -v "$HOME/.m2:/root/.m2" -v "/var/run/docker.sock:/var/run/docker.sock" "$IMAGE" bash