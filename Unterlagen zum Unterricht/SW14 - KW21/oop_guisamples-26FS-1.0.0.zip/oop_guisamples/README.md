# Modul OOP - GUI Samples

Dieses Projekt enthält einige __Codebeispiele__ zur GUI-Programmierung im Modul OOP.
Es basiert auf dem __oop_maven_template__, welches für diesen Zweck leicht
modifiziert und vereinfacht wurde.

## Verwendung

Die  Projekt kann einfach kopiert und umbenannt werden. In NetBeans, IntelliJ und 
Visual Studio Code kann es **direkt** geoeffnet werden, in Eclipse  ist 
ein **Import** des Projektes (als `Existing Maven Project`) notwendig. 

### AWT-Beispiel

Da die AWT-API integrierter Bestandteil des JDKs ist, kann es direkt in der IDE
gestartet werden. Die Klasse

* ch.hslu.oop.exercise.gui.awt.__SwitchGuiAwtDemo__

enthält das vollständige Beispiel mit einer __main()__-Methode.

### Swing-Beispiele

Da die Swing-API integrierter Bestandteil des JDKs ist, kann es direkt in der IDE
gestartet werden. Die Klassen

* ch.hslu.oop.exercise.gui.swing.__SwitchGuiSwingDemo__
* ch.hslu.oop.exercise.gui.swing.__SwitchGuiSwingDemoLookAndFeel__

enthalten das identische Beispiel mit einer __main()__-Methode. Bei der 
Variante __LookAndFeel__-kann aber in der Main-Methode zusätzlich noch der 
Plattformstil verändert werden.

### OpenFX-/JavaFX-Beispiele
Die FX-Technologie wird als externe Library verwendet und verwendet zusätzlich
die mit Java 9 eingeführte Modularisierung. Ein einfacher Start direkt in der IDE
ist (ohne zusätzliche, spezifische Konfiguration) nicht so einfach möglich.
Darum erfolgt der Start über Maven: 

`mvn javafx:run`

## Bereits enhaltene Libraries (Dependencies)

* JUnit 6 - https://junit.org/
* AssertJ - https://assertj.github.io/doc/
* EqualsVerifier - https://jqno.nl/equalsverifier/
* Simple Logging Facade (SLF4J) - https://www.slf4j.org/
* LogBack - https://logback.qos.ch/ (Default)

## Integrierte Analysewerkzeuge (Code Qualitaet)

* Checkstyle - https://checkstyle.sourceforge.io/
* PMD - https://pmd.github.io/
* JaCoCo - https://www.eclemma.org/jacoco/
* Spotbugs - https://spotbugs.github.io/

## Weitere Integrationen (benoetigen ggf. Konfiguration/Account)

* [GitLab CI/CD](https://docs.gitlab.com/ee/ci/) (.gitlab-ci.yml) inkl. Coverageauswertung fuer Java.
* [AsciiDoctor-Plugin](https://asciidoctor.org/) fuer [AsciiDoc](https://asciidoc.org/)

Feedback und Fehlermeldungen willkommen: roland.gisler@hslu.ch
